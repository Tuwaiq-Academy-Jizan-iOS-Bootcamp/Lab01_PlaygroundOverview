import UIKit

var name = "Nasser", lastName = "aseeri"

var age = 38

var myMessage = "My name is \(name) \(lastName) and I'am \(age) years old"

print(myMessage)
